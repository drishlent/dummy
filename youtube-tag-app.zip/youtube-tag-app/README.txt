Login to - https://console.cloud.google.com/ (use any gmail account(other than youtube's one))
Create a Project
stay inside the project
 search - Youtube Data API v3
          Enable
 Click on Credentials
	 Create API Key 
	 
	 
Copy API key to conf/dlite-external-prop.properties as below
	youtube.api.key1=API key
	youtube.api.key2=API key